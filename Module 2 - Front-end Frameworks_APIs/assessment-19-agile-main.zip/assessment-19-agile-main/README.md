# Agile: Assessment

## Brief

This assessment aims to crystalize your learning from the lesson and reflect upon your understandings of Agile SCRUM. Use your own words to answer these questions.

### Part 1 - Agile

Reflect on the [Agile Manifesto](https://agilemanifesto.org/), phrase them in no more than five sentences in your own words.

```
// Your response here
```

Agile Methodology does not just apply to software development but any project management. Recollect the 12 principles of Agile and share which three principles are commonly violated in your experience and what can be done differently?

```
// Your response here
```

### Part 2 - SCRUM

What are the three roles that make up a SCRUM Team? Explain the function(s) of the three roles.

```
// Your response here
```

What are the SCRUM Values? 

```
// Your response here
```

How many types of meetings are there in SCRUM? What is the purpose of each of them?
```
// Your response here
```


## Submission Guidelines

- Cite any relevant sources consulted during your research
- Solve the problems using your own code
- Do not copy and paste solutions from the source material
- Submit your assignment to black board.
