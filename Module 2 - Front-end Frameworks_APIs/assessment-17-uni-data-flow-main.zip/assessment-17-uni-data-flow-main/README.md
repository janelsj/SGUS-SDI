# Unidirectional Data Flow: Assessment

## Brief

This is a research assessment with an objective to broaden your knowledge in handling data flow in React. Thus far you have learned:
- What are states and props.
- How to manage the data flow across components using states and props.
- You should know that passing data from parent to child components using props.
- You should also learned about the importance of hoisting state.

Next, let's explore further on a possible limitation in React in regards to data handling.

Consider this diagram: 

<img src="./assets/images/assessment-17.png" />

How may `Component D` pass data to `Component F`? Do your research and give a response below. You should include these in your response:
- What are the options?
- Which option would you choose?
- The reason for the option you choose.

```
// Your response here.
```

## Submission Guidelines

- Cite any relevant sources consulted during your research
- Solve the problems using your own code
- Do not copy and paste solutions from the source material
- Submit your assignment to black board.
