# Deployment: Assessment

## Brief

Attempt to answer the questions below.

### Question 1 - What are environments in software deployment? How many are there?

```
// Your answer here
```

### Question 2 - What are purposes for the environments listed in Question1?

```
// Your answer here
```

### Question 3 - What are the best practices for software deployment?

```
// Your answer here
```

## Submission Guidelines

- Cite any relevant sources consulted during your research
- Solve the problems using your own code
- Do not copy and paste solutions from the source material
- Submit your assignment to black board.
