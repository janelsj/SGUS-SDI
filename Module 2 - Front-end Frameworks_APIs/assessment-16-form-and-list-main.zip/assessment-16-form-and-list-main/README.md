# Form and List: Assessment

## Brief

The objectives of this assessment aims to cover the knowledge gap from our practicals in both lesson and assignment.

### Part 1 - Decision on unique key

How would you produce a unique key according to the given array:

``` js
const persons = [
    {
        firstName:"Peterson",
        lastName:"Tan",
        lastFourNric:"123A",
        dateOfBirth:"01-03-1976"
        height:170,
        weight:77
    },
    ...
]

```

```
// Your answer here
```

### Part 2 - What happens if `key` attribute is ommitted

Research and find out what are the implications might happen to a React App if the `key` attribute is a modifiable listing. Give your explanation as in-dept as you can in your own words. 

```
// Your explanation here (minimum 100 word)
```

### Part 3 - How many ways are there in submitting a form

There is more than one way to submit a `<form>` in React, as well as in plain HTML. Find out what are the different ways to submit a form and show your code sample below.

```
Example one
```

```
Example two
```

and so on...

## Submission Guidelines

- Cite any relevant sources consulted during your research
- Solve the problems using your own code
- Do not copy and paste solutions from the source material
- Submit your assignment to black board.