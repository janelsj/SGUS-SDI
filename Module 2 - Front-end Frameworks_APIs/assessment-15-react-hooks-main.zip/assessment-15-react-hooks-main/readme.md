# React Hooks - Assessment 15

Q1: React Hooks are introduced to let you use state and other React features without writing a class component.

- **A: True**
- B: False

> Explaination:

Q2: Can React Hooks be used in a class component?

- A: Yes
- **B: No**

> Explaination:

Q3: How many different types of React Hooks are there in total?

- A: 2
- B: 3
- C: 5
- **D: 10**

> Explaination:

Q4: A state hook allows you to add state to a functional component.

- **A: True**
- B: False

> Explaination:

Q5: Which of the following is the correct way to use a state hook?

- A: const { setCount, count } = useState(0);
- B: const { count, setCount } = useState(0);
- **C: const [ count, setCount ] = useState(0);**
- D: const [ setCount, count ] = useState(0);

> Explaination:

Q6: You can only use State Hook once in a single component.

- A: True
- **B: False**

> Explaination:

Q7: Which of the following lifecycle method is Effect Hooks equivalent to?

- A: componentDidMount()
- B: componentDidUpdate()
- C: componentWillUnmount()
- **D: All of the above.**

> Explaination:

Q8: Which of the following is the correct way to use an Effect Hook?

- A: useEffect(() => { ... });
- B: useEffect(() => { ... }, []);
- C: useEffect(() => { ... }, [variableA]);
- **D: All of the above.**

> Explaination:

Q9: Which of the following lifecycle method is the same as having a return statement in an Effect Hook?

- A: componentDidMount()
- B: componentDidUpdate()
- **C: componentWillUnmount()**
- D: All of the above.

> Explaination:

Q10: Does useEffect run after every render?

- A: Yes, always.
- **B: Yes, by default.**
- C: No, always.
- D: No, by default.

> Explaination:
