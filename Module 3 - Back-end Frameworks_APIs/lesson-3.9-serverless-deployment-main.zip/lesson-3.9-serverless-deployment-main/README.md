# Serverless Deployment

## Brief

Follow official guide to deploy node.js application. No step by step provided in case official guide changes. 

https://devcenter.heroku.com/articles/deploying-nodejs

